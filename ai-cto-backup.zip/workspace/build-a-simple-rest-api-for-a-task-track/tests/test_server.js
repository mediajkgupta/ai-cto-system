const request = require('supertest');
const app = require('../server.js');

describe('Task Tracker REST API', () => {

  // Test for POST on /tasks
  describe('POST /tasks', () => {
    it('should create a new task', async () => {
      const res = await request(app).post('/api/tasks').send({ title: 'Test Task', description: 'This is a test task.' });
      expect(res.statusCode).toEqual(201);
      expect(res.body.title).toEqual('Test Task');
      expect(res.body.description).toEqual('This is a test task.');
    });
  });

  // Test for GET on /tasks
  describe('GET /tasks', () => {
    it('should get all tasks', async () => {
      const res = await request(app).get('/api/tasks');
      expect(res.statusCode).toEqual(200);
      expect(Array.isArray(res.body)).toBeTruthy();
    });
  });

  // Test for PUT on /tasks/:id
  describe('PUT /tasks/:id', () => {
    it('should update a task', async () => {
      const res = await request(app).put('/api<｜begin▁of▁sentence｜>i/tasks/1').send({ title: 'Updated Task', description: 'This is an updated test task.' });
      expect(res.statusCode).toEqual(200);
      expect(res.body.title).toEqual('Updated Task');
      expect(res.body.description).toEqual('This is an updated test task.');
    });
  });

  // Test for DELETE on /tasks/:id
  describe('DELETE /tasks/:id', () => {
    it('should delete a task', async () => {
      const res = await request(app).delete('/api/tasks/1');
      expect(res.statusCode).toEqual(200);
      expect(res.body.message).toEqual('Task deleted successfully.');
    });
  });
});