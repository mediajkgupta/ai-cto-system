"""
Auto-generated tests for Todo API (MOCK_LLM mode).
Run from workspace/<project_id>/ with: pytest tests/
"""
import sys
import os
import importlib
import pytest

# Allow importing main.py from the workspace root
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


@pytest.fixture(autouse=True)
def reset_todos():
    """Reset in-memory state before every test."""
    import main
    main._todos.clear()
    main._next_id = 1
    yield
    main._todos.clear()
    main._next_id = 1


def test_create_todo_returns_dict():
    import main
    todo = main.create_todo("Test task")
    assert isinstance(todo, dict)
    assert todo["title"] == "Test task"
    assert todo["done"] is False
    assert "id" in todo


def test_create_todo_increments_id():
    import main
    t1 = main.create_todo("First")
    t2 = main.create_todo("Second")
    assert t2["id"] == t1["id"] + 1


def test_create_todo_rejects_empty_title():
    import main
    with pytest.raises(ValueError):
        main.create_todo("   ")


def test_get_all_todos_returns_list():
    import main
    main.create_todo("A")
    main.create_todo("B")
    todos = main.get_all_todos()
    assert len(todos) == 2


def test_get_todo_by_id():
    import main
    todo = main.create_todo("Find me")
    found = main.get_todo(todo["id"])
    assert found is not None
    assert found["title"] == "Find me"


def test_get_todo_returns_none_for_missing():
    import main
    assert main.get_todo(9999) is None


def test_update_todo_marks_done():
    import main
    todo = main.create_todo("Mark me")
    result = main.update_todo(todo["id"], done=True)
    assert result is not None
    assert result["done"] is True


def test_update_nonexistent_returns_none():
    import main
    assert main.update_todo(9999, done=True) is None


def test_delete_todo_removes_item():
    import main
    todo = main.create_todo("Delete me")
    assert main.delete_todo(todo["id"]) is True
    assert main.get_todo(todo["id"]) is None


def test_delete_nonexistent_returns_false():
    import main
    assert main.delete_todo(9999) is False
