import pytest
from models.task import Task

def test_create_task():
    task = Task('Test Task', 'This is a test task')
    assert task.title == 'Test Task'
    assert task.description == 'This is a test task'