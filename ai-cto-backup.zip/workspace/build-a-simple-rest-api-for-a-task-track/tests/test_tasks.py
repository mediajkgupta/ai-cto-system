import pytest
from unittest.mock import Mock, patch
import tasks

@patch('models.task.Task')
@patch('api.tasks.requests')
def test_create_new_task(MockTask, requests):
    requests.post.return_value = 'http://fakeurl'
    MockTask.objects.create.return_value = {'_id': 123}
    result = tasks.create_new_task('Test Task')
    assert result == {'_id': 123, 'description': 'Test Task', 'status': False}
