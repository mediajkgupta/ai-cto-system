
const mongoose = require('mongoose');
mongoose.connect(process.env.MONGODB_URL || 'mongodb://localhost:27017/task-tracker', { useNewUrlParser: true, useUnifiedTopology: true });
